CREATE TABLE person(
    id int auto_increment,
    username text not null,
    pswd text not null,
    primary key(id)
);

insert into person(username, pswd) values("wendy_mengo", "12345678");
insert into person(username, pswd) values("john_smith", "09876543");

CREATE TABLE task(
    id int auto_increment,
    title text not null,
    descr text not null,
    done boolean not null,
    pid int not null,
    primary key(id),
    foreign key(pid) references person(id)
);

insert into task(title, descr, done, pid) values ("eat dinner", "eat ramen today", false, 1);

CREATE TABLE comment(
    id int auto_increment,
    tid int not null,
    cmt text not null,
    primary key(id),
    foreign key(tid) references task(id)
);

insert into comment(tid, cmt) values (1, "I love ramen so much");