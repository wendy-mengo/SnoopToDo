const mysql = require(`mysql-await`); 

var connPool = mysql.createPool({
  connectionLimit: 5,
  host: "127.0.0.1",
  port: 3307,
  user: "C4131F24U84",
  database: "C4131F24U84",
  password: "7106"
});

async function newPerson(username, password){
  const result = await connPool.awaitQuery("insert into person(username, pswd) values (?, ?);", [username, password])
  return result.insertId
}

async function getPassword(username){
  const result = await connPool.awaitQuery("select pswd from person where username = ?;", [username])
  return result[0].pswd
}

async function getPid(username){
  const result = await connPool.awaitQuery("select id from person where username = ?;", [username])
  return result[0].id
}

async function newTask(title, descr, pid){
  const result = await connPool.awaitQuery("insert into task(title, descr, done, pid) values (?, ?, ?, ?);", [title, descr, false, pid])
  return result.insertId
}

async function deleteTask(id){
  const result = await connPool.awaitQuery("delete from task where id = ?;", [id])
  return result
}

async function getTasks(pid){
  const result = await connPool.awaitQuery("select * from task where pid = ?;", [pid])
  return result
}

async function getDoneTask(done, pid){
  const result = await connPool.awaitQuery("select * from task where done = ? and pid = ?;", [done, pid])
  return result
}

async function specificTask(id){
  const result = await connPool.awaitQuery("select * from task where id = ?;", [id])
  return result[0]
}

async function newComment(tid, cmt){
  const result = await connPool.awaitQuery("insert into comment(tid, cmt) values (?, ?);", [tid, cmt])
  return result.insertId
}

async function deleteComment(id){
  const result = await connPool.awaitQuery("delete from comment where id = ?;", [id])
  return result
}

async function getComments(tid){
  const result = await connPool.awaitQuery("select * from comment where tid = ?;", [tid])
  return result
}
async function specificComment(cid){
  const result = await connPool.awaitQuery("select * from comment where id = ?;", [cid])
  return result
}

async function changeDone(bool, tid){
  const result = await connPool.awaitQuery("update task set done = ? where id = ?;", [bool, tid])
}

async function newDescription(tid, descr){
  const result = await connPool.awaitQuery("update task set descr = ? where id = ?;", [descr, tid])
}
async function getDone(tid){
  const result = await connPool.awaitQuery("select done from task where id = ?", [tid])
  return result[0].done
}
module.exports = {
    newPerson,
    getPassword,
    getPid,
    newTask,
    deleteTask,
    getTasks,
    getDoneTask,
    specificTask,
    newComment,
    deleteComment,
    getComments,
    specificComment,
    changeDone,
    newDescription,
    getDone
};