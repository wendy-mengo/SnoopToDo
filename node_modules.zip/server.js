const express = require('express')
const data = require("./data")
const session = require('express-session')
const app = express()
app.use(express.static(__dirname + '/resources'))
app.use(express.urlencoded({extended:true}))
app.use(express.json())
app.set("views", "templates");
app.set("view engine", "pug")
app.set('trust proxy', 1)
app.use(session({
    secret: "mlhgfhjk",
    resave: false,
    saveUninitialized: false,
    cookie:{cookie: {
        secure: true,
        httpOnly: true, 
        maxAge: 24 * 60 * 60 * 1000 
    }}
}))
const port = 4131

const requireLogin = (req, res, next) => {
    if (req.session.user && req.session.user.loggedIn) {
        next();
    } else {
        res.redirect('/login');
    }
};

app.get("/", (req, res)=>{
    res.render("home.pug")
})

app.get("/login", (req, res)=>{
    res.render("loginpage.pug")
})

app.get("/add", requireLogin, (req, res)=>{
    res.render("add.pug")
})

app.get("/aboutus", (req, res)=>{
    res.render("aboutus.pug")
})

app.get("/newPerson", (req,res)=>{
    res.render("createPerson.pug")
})

app.post("/newPerson", async(req, res) => {
    const result = await data.newPerson(req.body.username, req.body.password)
    res.render("loginpage.pug")
})

app.get('/:id/viewall', requireLogin, async (req, res) => {
    const userId = req.session.user.id;
    const tasks = await data.getTasks(userId)
    res.render("view.pug", {"tasks": tasks, "id": userId})
})

app.get("/:id/notdone", requireLogin, async (req, res) => {
    const userId = req.session.user.id;
    const tasks = await data.getDoneTask(false, userId)
    res.render("view.pug", {"tasks": tasks, "id": userId})
})

app.get('/:id/viewdone', requireLogin, async (req, res) => {
    const userId = req.session.user.id;
    const tasks = await data.getDoneTask(true, userId)
    res.render("view.pug", {"tasks": tasks, "id": userId})
})

app.get('/api/check', async (req, res) => {
    try {
        const tid = req.query.tid;
        if (!tid) {
            return res.status(400).json({ message: 'Task ID is required' });
        }

        const result = await data.getDone(tid); 
        res.status(200).json({ bool: result });
    } catch (error) {
        console.error('Error getting task status:', error);
        res.status(500).json({ message: 'Failed to get task status' });
    }
});


app.get("*task/:id", async(req, res)=>{
    const task = await data.specificTask(req.params.id)
    const comments = await data.getComments(req.params.id)
    res.render("task.pug", {"task": task, "comments": comments, "id": req.params.id})
})

app.post("/api/checked", async(req, res) => {
    try {
        await data.changeDone(req.body.done, req.body.tid);
        res.status(200).json({ message: 'Task status updated' });
    } catch (error) {
        console.error('Error updating task:', error);
        res.status(500).json({ message: 'Failed to update task' });
    }
});

app.post("/login", async(req, res)=>{
    try {
        const password = await data.getPassword(req.body.username)
        
        if (req.body.password === password){
            const id = await data.getPid(req.body.username)
            
            req.session.user = {
                id: id,
                username: req.body.username,
                loggedIn: true
            }
                res.redirect(`/${id}/viewall`);
        } else {
            res.render("loginfail.pug")
        }
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).render("error.pug");
    }
})

app.get('/check-login', (req, res) => {
    res.json({ 
        loggedIn: req.session.user && req.session.user.loggedIn 
    });
});

app.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error('Logout error:', err)
        }
        res.redirect('/login')
    })
})

app.post("/add", async(req, res)=>{
    const userId = req.session.user.id;
    const id = await data.newTask(req.body.title, req.body.descr, userId)
    const tasks = await data.getTasks(true, userId)
    res.render("view.pug", {"tasks": tasks, "id": userId})
})

app.delete('/api/delete_task', async(req, res) => {
    const tid = req.body.tid;
    
    if (!tid) {
        return res.status(400).json({ error: 'No task ID provided' });
    }

    const id = await data.deleteTask(tid)
    const tasks = await data.getTasks()
    res.render("view.pug", {"tasks": tasks})
})

app.post('/api/new_comment', async(req, res) => {
    try {
        const comment = {
            tid: req.body.tid,
            comment: req.body.comment
        }

        if(comment.comment === ''){
            return res.status(400).json({ error: 'Invalid comment data' })
        }


        await data.newComment(comment.tid, comment.comment)
        const comments = await data.getComments(comment.tid)
        return res.status(201).json({
            comments: comments,
        })

    } catch (error) {
        console.error('Error adding comment:', error)
        return res.status(500).json({ error: 'Failed to add comment' })
    }
})
app.delete('/api/delete_comment', async(req, res) => {
    try {
        const cid = req.body.cid;
        
        if (!cid) {
            return res.status(400).json({ error: 'No comment ID provided' });
        }
        
        const tid = await data.specificComment(cid)
        await data.deleteComment(cid)
        const comments = await data.getComments(tid[0].tid) 
        
        res.status(200).json({ comments: comments });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Server error' });
    }
})

app.post('/api/new_descr', async(req, res) => {
    try {
        const description = {
            tid: req.body.tid,
            descr: req.body.descr
        }

        if(description.descr === ''){
            return res.status(400).json({ error: 'Invalid description data' })
        }
        await data.newDescription(description.tid, description.descr)
        return res.status(201).json({})

    } catch (error) {
        console.error('Error editing description:', error)
        return res.status(500).json({ error: 'Failed to edit description' })
    }
})

app.listen (port , () => {
    console.log(`Example app listening on port ${port}`)
  })