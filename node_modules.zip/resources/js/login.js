document.addEventListener('DOMContentLoaded', () => {
    fetch('/check-login')
        .then(response => response.json())
        .then(data => {
            const signInLink = document.querySelector('li.button a[href="/login"]');
            
            if (data.loggedIn) {
                signInLink.textContent = 'sign out';
                signInLink.href = '/logout';
            } else {
                signInLink.textContent = 'sign in';
                signInLink.href = '/login';
            }
        })
        .catch(error => {
            console.error('Error checking login status:', error);
        });
});