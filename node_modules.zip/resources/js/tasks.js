window.onload = async function () {
    const id = document.getElementById("hidden").innerText.trim();

    try {
        const response = await fetch(`/api/check?tid=${id}`, {
            method: 'GET',
            headers: {
                'Content-type': 'application/json',
            },
            credentials: 'include',
        })

        if (response.ok) {
            const data = await response.json()
            document.querySelector('#done').checked = data.bool
        } else {
            console.error('Failed to get task status')
        }
    } catch (error) {
        console.error('Error getting task status:', error)
    }
}
const doneCheckbox = document.querySelector('#done');
doneCheckbox.addEventListener('change', async function () {
    const id = document.getElementById('hidden').innerText.trim(); 
    const done = {
        done: this.checked,
        tid: id
    };
    const currentCheckedState = this.checked; 

    try {
        const response = await fetch("/api/checked", {
            method: 'POST',
            headers: {
                'Content-type': 'application/json',
            },
            body: JSON.stringify(done),
            credentials: 'include'
        });

        if (response.ok) {
            console.log('Task done status updated');
        } else {
            console.error('Failed to update task status');
            this.checked = !currentCheckedState; 
        }
    } catch (error) {
        console.error('Error updating task status:', error);
        this.checked = !currentCheckedState; 
    }
});


function newComment() {
    let button = document.querySelector("#newComment");
    let form = document.querySelector("#new");

    if (button.innerHTML === "add comment") {
        form.style.display = 'inline';  
        button.innerHTML = "cancel comment"; 
    } else {
        form.style.display = 'none';  
        button.innerHTML = "add comment";  
    }
}


async function submitComment(){
    const cmt = document.getElementById('comment').value;
    const id = document.getElementById('hidden').innerText;
    const comment = {
        comment: cmt,
        tid: id 
    }

    try {
        fetch('/api/new_comment', {
            method: 'POST',
            headers: {
                'Content-type': 'application/json',
            },
            body: JSON.stringify(comment),
            credentials: 'include'
        }).then(async (response) => {
            if (response.status == 400) {
                document.getElementById("comment").style.borderColor="#FF0000";
            }
            else if(response.status == 201){
                const data = await response.json();
                let listComment = document.getElementById('listComment');
                listComment.innerHTML = '';
                data.comments.forEach(comment => {
                    let item = document.createElement('div');
                    item.innerHTML = `<div class="comm" data-id=${comment.id}"><p>${comment.cmt}</p> <button onclick="deleteCmt(${comment.id})')" >delete</button></div>`;
                    listComment.appendChild(item);
                });
                document.getElementById('comment').value = '';
                document.getElementById("comment").style.borderColor="";

                let button = document.getElementById("newComment");
                let form = document.querySelector("#new");
                button.innerText = "add comment";
                form.style.display = 'none';  
            }
        })    
    }catch{
        alert("Error")
    }
} 

async function deleteCmt(id){
    try {
        const cmt = {
            cid: id
        }
        const response = await fetch("/api/delete_comment", {
            method: 'DELETE',
            headers: {
                'Content-type': 'application/json'
            },
            body: JSON.stringify(cmt)
        });

        if (response.ok) {  
            const data = await response.json();
            let listComment = document.getElementById('listComment');
            listComment.innerHTML = '';
            
            data.comments.forEach(comment => {
                let item = document.createElement('div');
                item.innerHTML = `
                    <div class="comm" data-id="${comment.id}">
                        <p>${comment.cmt}</p>
                        <button onclick="deleteCmt(${comment.id})">delete</button>
                    </div>
                `;
                listComment.appendChild(item);
            });
        } else {
            if (response.status === 404) {
                console.log("Error 404: Resource not found.");
            } else if (response.status === 400 || response.status === 500) {
                alert("Error " + response.status);
            }
        }
    } catch (error) {
        console.error("Delete comment error:", error);
        alert("Error deleting comment");
    }
}

function editDescr() {
    let button = document.querySelector("#editDescr");
    let form = document.querySelector("#newDescr");
    let des = document.querySelector("#descrip")

    if (button.innerHTML === "edit") {
        form.style.display = 'inline'; 
        des.style.display = 'none' 
        button.innerHTML = "cancel edit"; 
    } else {
        des.style.display = 'inline'
        form.style.display = 'none';  
        button.innerHTML = "edit";  
    }
}


async function submitDescr(){
    const descr = document.getElementById('editdescription').value;
    const id = document.getElementById('hidden').innerText;
    const description = {
        descr: descr,
        tid: id 
    }

    try {
        fetch('/api/new_descr', {
            method: 'POST',
            headers: {
                'Content-type': 'application/json',
            },
            body: JSON.stringify(description),
            credentials: 'include'
        }).then(async (response) => {
            if (response.status == 400) {
                document.getElementById("editdescription").style.borderColor="#FF0000";
            }
            else if(response.status == 201){
                document.getElementById('editdescription').value = '';
                document.getElementById("editdescription").style.borderColor="";

                let button = document.getElementById("editDescr");
                let form = document.querySelector("#newDescr");
                let des = document.querySelector("#descrip")
                des.style.display = 'inline'
                button.innerText = "edit";
                form.style.display = 'none';  
                window.location.reload();
            }
        })    
    }catch{
        alert("Error")
    }
} 