async function deleteTask(id){
    try {
        const task = {
            tid: id
        }
        const response = await fetch("/api/delete_task", {
            method: 'DELETE',
            headers: {
                'Content-type': 'application/json'
            },
            body: JSON.stringify(task)

        });
            if (response.ok) {  
            let rows = document.querySelectorAll("#row");
            rows.forEach((row) => {
                if (row.children['tid'].attributes.value.value == id.attributes.value.value) {
                    row.remove();
                }
            });
            window.location.reload();
        } else {
            if (response.status === 404) {
                console.log("Error 404: Resource not found.");
                let rows = document.querySelectorAll("#row");
                rows.forEach((row) => {
                    if (row.children['listing_id'].attributes.value.value == id) {
                        row.remove();
                    }
                });
            } else if (response.status === 400 || response.status === 500) {
                alert("Error " + response.status);
            }
        }
    } catch (error) {
        alert("Error " + response.status);
    }
}
